# CLI Market Product Intelligence — Sistema multiagente

## Arquitectura

- **Orquestador:** controla el flujo y consolida la decisión.
- **Brief Architect:** delimita el problema y los supuestos.
- **Scientific Evidence:** valida evidencia científica, tecnológica y patentaria.
- **Market Intelligence:** analiza góndola, precios, marcas, formatos y retailers.
- **Regulatory Readiness:** revisa claims, etiquetado y requisitos.
- **Competitive Product Designer:** diseña conceptos competitivos.
- **Commercial Feasibility:** analiza precio, canal y viabilidad preliminar.
- **Red Team Critic:** intenta refutar la tesis de oportunidad.
- **Opportunity Dossier Writer:** produce la ficha ejecutiva.

## Instalación

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="..."
```

En Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
$env:OPENAI_API_KEY="..."
```

## Contextos de datos

El MVP lee snapshots JSON mediante variables de entorno:

```bash
export CLI_MARKET_CONTEXT_FILE="./data/cli_market_snapshot.json"
export SCIENTIFIC_CONTEXT_FILE="./data/scientific_snapshot.json"
export REGULATORY_CONTEXT_FILE="./data/regulatory_snapshot.json"
```

Esta capa debe reemplazarse luego por conectores API/MCP reales.

## Ejecución

```bash
python cli_product_intelligence_agents.py   --product "Snack proteico de quinua"   --market "Perú"   --segment "jóvenes profesionales"   --stage "concepto"   --constraint "sin azúcar añadida"
```
