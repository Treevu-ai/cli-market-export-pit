"""
CLI Market Product Intelligence
Agente orquestador + subagentes especializados.

Requisitos:
    pip install openai-agents pydantic python-dotenv

Variables de entorno:
    OPENAI_API_KEY=...
    CLI_MARKET_CONTEXT_FILE=./data/cli_market_snapshot.json   # opcional
    SCIENTIFIC_CONTEXT_FILE=./data/scientific_snapshot.json   # opcional
    REGULATORY_CONTEXT_FILE=./data/regulatory_snapshot.json   # opcional

Ejecución:
    python cli_product_intelligence_agents.py \
      --product "Snack proteico de quinua" \
      --market "Perú" \
      --segment "jóvenes profesionales" \
      --stage "concepto"
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
from typing import Any

from agents import Agent, Runner, function_tool
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# 1. Contratos de entrada y salida
# ---------------------------------------------------------------------------

class ProductBrief(BaseModel):
    product: str = Field(description="Producto o concepto a evaluar.")
    market: str = Field(description="Mercado local o internacional objetivo.")
    segment: str = Field(description="Segmento de cliente o consumidor.")
    stage: str = Field(description="Etapa: idea, concepto, prototipo, piloto o escalamiento.")
    objective: str = Field(
        default=(
            "Determinar si existe una oportunidad defendible y cómo diseñar "
            "un producto competitivo antes de comprometer inversión relevante."
        )
    )
    constraints: list[str] = Field(default_factory=list)


class AgentFinding(BaseModel):
    agent: str
    executive_summary: str
    findings: list[str]
    opportunities: list[str]
    risks: list[str]
    evidence_gaps: list[str]
    confidence: str = Field(description="alta, media o baja")
    sources_used: list[str] = Field(default_factory=list)


class FinalRecommendation(BaseModel):
    decision: str = Field(description="GO, CONDITIONAL GO, PIVOT o NO-GO")
    opportunity_thesis: str
    target_market: str
    target_segment: str
    product_concept: str
    differentiation: list[str]
    recommended_price_position: str
    channels: list[str]
    key_claims: list[str]
    must_validate_next: list[str]
    major_risks: list[str]
    first_30_day_actions: list[str]
    confidence: str


# ---------------------------------------------------------------------------
# 2. Herramientas de contexto
# ---------------------------------------------------------------------------

def _load_json_file(env_name: str) -> dict[str, Any]:
    path = os.getenv(env_name)
    if not path:
        return {
            "status": "not_configured",
            "message": f"No se configuró {env_name}. No inventar datos.",
        }

    file_path = Path(path)
    if not file_path.exists():
        return {
            "status": "missing",
            "message": f"No existe el archivo indicado en {env_name}: {file_path}",
        }

    try:
        return {
            "status": "ok",
            "path": str(file_path),
            "data": json.loads(file_path.read_text(encoding="utf-8")),
        }
    except (OSError, json.JSONDecodeError) as exc:
        return {"status": "error", "message": str(exc)}


@function_tool
def load_cli_market_context() -> str:
    """
    Carga datos de góndola, marcas, precios, formatos, retailers y competencia
    obtenidos previamente desde CLI Market. No sustituye la integración API/MCP.
    """
    return json.dumps(
        _load_json_file("CLI_MARKET_CONTEXT_FILE"),
        ensure_ascii=False,
    )


@function_tool
def load_scientific_context() -> str:
    """
    Carga evidencia científica y tecnológica obtenida previamente de fuentes
    como OpenAlex, Crossref, Semantic Scholar o bases de patentes.
    """
    return json.dumps(
        _load_json_file("SCIENTIFIC_CONTEXT_FILE"),
        ensure_ascii=False,
    )


@function_tool
def load_regulatory_context() -> str:
    """
    Carga requisitos regulatorios y de etiquetado del mercado objetivo.
    Deben provenir de fuentes oficiales o revisión humana validada.
    """
    return json.dumps(
        _load_json_file("REGULATORY_CONTEXT_FILE"),
        ensure_ascii=False,
    )


# ---------------------------------------------------------------------------
# 3. Subagentes
# ---------------------------------------------------------------------------

brief_agent = Agent(
    name="CLI Brief Architect",
    instructions="""
Eres el subagente que convierte una idea de producto en un brief analizable.

Tu tarea:
1. Delimitar producto, mercado, segmento, ocasión de consumo y etapa.
2. Identificar supuestos críticos.
3. Separar hechos aportados por el usuario de hipótesis.
4. Formular las preguntas de decisión que deben resolver los demás agentes.
5. No concluir si el producto es viable todavía.

Entrega un brief ejecutivo y una lista priorizada de hipótesis por validar.
Escribe en español profesional y evita lenguaje promocional.
""",
)

scientific_agent = Agent(
    name="Scientific Evidence Agent",
    instructions="""
Evalúas el respaldo científico y tecnológico de una iniciativa de producto.

Debes:
- Usar load_scientific_context antes de emitir hallazgos.
- Identificar evidencia favorable, evidencia contradictoria y vacíos.
- Distinguir asociación, mecanismo plausible y causalidad demostrada.
- Revisar publicaciones, citación, vigencia, patentes y madurez tecnológica.
- Señalar claims que NO podrían sostenerse con la evidencia disponible.
- No inventar papers, autores, DOI, patentes ni resultados.

Entrega:
resumen, hallazgos, oportunidades, riesgos, vacíos, confianza y fuentes usadas.
""",
    tools=[load_scientific_context],
)

market_agent = Agent(
    name="CLI Market Intelligence Agent",
    instructions="""
Analizas la realidad competitiva del producto en el mercado objetivo.

Debes:
- Usar load_cli_market_context antes de emitir cifras o comparaciones.
- Mapear retailers, marcas, precios, formatos, tamaños, claims y arquitectura
  de categoría.
- Detectar pisos, techos, concentración, espacios vacíos y señales de saturación.
- Comparar precio por unidad equivalente cuando los datos lo permitan.
- Diferenciar claramente datos observados de inferencias.
- Si faltan datos, declararlo; jamás fabricar precios o competidores.

Entrega:
resumen, hallazgos, oportunidades, riesgos, vacíos, confianza y fuentes usadas.
""",
    tools=[load_cli_market_context],
)

regulatory_agent = Agent(
    name="Regulatory Readiness Agent",
    instructions="""
Evalúas restricciones regulatorias, etiquetado, claims, inocuidad, certificaciones
y requisitos de ingreso al mercado.

Debes:
- Usar load_regulatory_context.
- Separar requisito obligatorio, buena práctica y recomendación comercial.
- Identificar afirmaciones de marketing con riesgo regulatorio.
- Marcar cualquier punto que requiera validación legal o técnica humana.
- No emitir asesoría legal definitiva ni inventar normas.

Entrega:
resumen, hallazgos, oportunidades, riesgos, vacíos, confianza y fuentes usadas.
""",
    tools=[load_regulatory_context],
)

product_design_agent = Agent(
    name="Competitive Product Designer",
    instructions="""
Diseñas una arquitectura competitiva de producto usando el brief y los resultados
de ciencia, mercado y regulación.

Define:
- Segmento y necesidad prioritaria.
- Propuesta de valor.
- Formato, tamaño, experiencia de uso y atributos.
- Ingredientes o componentes a incluir y evitar.
- Claims defendibles.
- Diferenciación relevante y verificable.
- Tres conceptos: conservador, diferenciador y disruptivo.

No sugieras beneficios que excedan la evidencia ni ignores restricciones
regulatorias. Toda recomendación debe vincularse con un hallazgo previo.
""",
)

economics_agent = Agent(
    name="Commercial Feasibility Agent",
    instructions="""
Evalúas viabilidad comercial preliminar.

Analiza:
- Posicionamiento de precio: value, mainstream, premium o superpremium.
- Corredor de precio observable.
- Hipótesis de margen y principales drivers de costo.
- Canales prioritarios.
- Riesgo de canibalización y barreras de adopción.
- Experimentos comerciales de bajo costo.

No inventes costos, elasticidades, márgenes ni volúmenes. Cuando falten datos,
formula rangos, variables y pruebas necesarias, no cifras falsas.
""",
)

critic_agent = Agent(
    name="Red Team Opportunity Critic",
    instructions="""
Actúas como comité de inversión adversarial.

Debes cuestionar:
- Calidad de evidencia.
- Tamaño y claridad del espacio competitivo.
- Diferenciación real versus cosmética.
- Riesgo regulatorio.
- Coherencia entre segmento, precio, canal y formato.
- Supuestos no validados.
- Posibles razones de fracaso.

Asigna una recomendación preliminar:
GO, CONDITIONAL GO, PIVOT o NO-GO.

No suavices riesgos para hacer atractivo el proyecto.
""",
)

report_agent = Agent(
    name="Opportunity Dossier Writer",
    instructions="""
Consolidas los resultados en una Ficha de Oportunidad de Producto accionable.

Estructura:
1. Decisión ejecutiva.
2. Tesis de oportunidad.
3. Evidencia científica y tecnológica.
4. Radar de mercado y góndola.
5. Arquitectura competitiva del producto.
6. Posicionamiento de precio y canal.
7. Riesgos y vacíos de evidencia.
8. Experimentos de validación.
9. Plan de acción de 30 días.

Reglas:
- Distingue hechos, inferencias e hipótesis.
- Conserva las advertencias del agente crítico.
- No inventes datos.
- La recomendación final debe ser GO, CONDITIONAL GO, PIVOT o NO-GO.
- Escribe para un comité ejecutivo, no como publicidad.
""",
)


# ---------------------------------------------------------------------------
# 4. Agente orquestador
# ---------------------------------------------------------------------------

orchestrator_agent = Agent(
    name="CLI Product Intelligence Orchestrator",
    instructions="""
Eres el agente orquestador de CLI Market Product Intelligence.

Tu misión es reducir incertidumbre antes de invertir en el desarrollo o
lanzamiento de un producto para un mercado local o internacional.

Secuencia obligatoria:
1. Llama a build_product_brief.
2. Llama a scientific_evidence, market_intelligence y regulatory_readiness.
3. Con esos resultados, llama a competitive_product_design.
4. Llama a commercial_feasibility.
5. Llama a red_team_review.
6. Finalmente llama a write_opportunity_dossier.

No reemplaces a los especialistas con tu propio conocimiento.
No inventes datos para completar vacíos.
La salida final debe ser una ficha ejecutiva en Markdown, con:
- decisión,
- tesis,
- evidencias,
- diseño recomendado,
- precio/canal,
- riesgos,
- validaciones pendientes,
- acciones de 30 días.

Cuando la evidencia sea insuficiente, la decisión correcta suele ser
CONDITIONAL GO, PIVOT o NO-GO, no una recomendación optimista sin sustento.
""",
    tools=[
        brief_agent.as_tool(
            tool_name="build_product_brief",
            tool_description="Convierte la idea inicial en un brief y define hipótesis críticas.",
        ),
        scientific_agent.as_tool(
            tool_name="scientific_evidence",
            tool_description="Evalúa evidencia científica, tecnológica y patentaria.",
        ),
        market_agent.as_tool(
            tool_name="market_intelligence",
            tool_description="Analiza góndola, competencia, precios, formatos y espacios de mercado.",
        ),
        regulatory_agent.as_tool(
            tool_name="regulatory_readiness",
            tool_description="Evalúa regulación, etiquetado, claims y requisitos del mercado.",
        ),
        product_design_agent.as_tool(
            tool_name="competitive_product_design",
            tool_description="Diseña conceptos de producto basados en la evidencia consolidada.",
        ),
        economics_agent.as_tool(
            tool_name="commercial_feasibility",
            tool_description="Evalúa posicionamiento, canal, margen preliminar y pruebas comerciales.",
        ),
        critic_agent.as_tool(
            tool_name="red_team_review",
            tool_description="Cuestiona la oportunidad y recomienda GO, CONDITIONAL GO, PIVOT o NO-GO.",
        ),
        report_agent.as_tool(
            tool_name="write_opportunity_dossier",
            tool_description="Redacta la Ficha de Oportunidad de Producto para decisión ejecutiva.",
        ),
    ],
)


# ---------------------------------------------------------------------------
# 5. Ejecución
# ---------------------------------------------------------------------------

async def run_analysis(brief: ProductBrief) -> str:
    prompt = f"""
Analiza la siguiente iniciativa:

{brief.model_dump_json(indent=2)}

Usa la secuencia completa de subagentes. No omitas ciencia, mercado,
regulación, diseño, viabilidad comercial, red team ni síntesis final.
"""
    result = await Runner.run(orchestrator_agent, prompt, max_turns=30)
    return result.final_output


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="CLI Market Product Intelligence multi-agent workflow"
    )
    parser.add_argument("--product", required=True)
    parser.add_argument("--market", required=True)
    parser.add_argument("--segment", required=True)
    parser.add_argument("--stage", default="concepto")
    parser.add_argument("--objective", default=ProductBrief.model_fields["objective"].default)
    parser.add_argument(
        "--constraint",
        action="append",
        default=[],
        help="Puede repetirse para añadir varias restricciones.",
    )
    return parser.parse_args()


async def main() -> None:
    args = parse_args()
    brief = ProductBrief(
        product=args.product,
        market=args.market,
        segment=args.segment,
        stage=args.stage,
        objective=args.objective,
        constraints=args.constraint,
    )
    output = await run_analysis(brief)
    print(output)


if __name__ == "__main__":
    asyncio.run(main())
