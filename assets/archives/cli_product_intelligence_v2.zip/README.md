# CLI Market Product Intelligence v2

Esta versión amplía la arquitectura anterior con instrucciones operativas completas para cada actor.

## Archivos

- `ESPECIFICACION_AGENTES.md`: documento detallado de roles, contexto, tareas, acciones, formatos, reglas y criterios.
- `agent_instructions.py`: prompts estructurados listos para integrar en OpenAI Agents SDK u otro framework.

## Alcance

El sistema evalúa iniciativas de desarrollo de producto para mercados locales o internacionales mediante:

1. estructuración del brief;
2. evidencia científica;
3. inteligencia de mercado;
4. regulación;
5. diseño competitivo;
6. viabilidad comercial;
7. revisión adversarial;
8. síntesis ejecutiva.

## Decisiones admitidas

- GO
- CONDITIONAL GO
- PIVOT
- NO-GO
